import os
import shutil
import json

PACKAGE_DIR = os.path.abspath("..//package")
INSTALLED_PACKAGE_DIR = os.path.abspath(".///installed_package")

ins_json_path = os.path.join(INSTALLED_PACKAGE_DIR, "installed.json")

def check_pkg():
    with open(ins_json_path) as f:
        installed = json.load(f)

    for pkg_name, pkg_data in installed.items():
        name = pkg_data.get("name", pkg_name)
        version = pkg_data.get("version", "unknown")
        print(f"{name} ({version})")

def install_pkg(pkg_name):
    full_path = os.path.join(PACKAGE_DIR, pkg_name)
    
    if not os.path.exists(full_path):
        print("No package in query at package manager")
        return
    
    pkg_manifest = os.path.join(full_path, "manifest.json")
    
    if not os.path.exists(pkg_manifest):
        print("Package has not founded manifest.json")
        return
    
    try:
        with open(ins_json_path, "r") as f:
            installed = json.load(f)
    except (json.JSONDecodeError, FileNotFoundError):
            installed = {}
        
    if pkg_name in installed:
        print("Package already installed")
        return
        
    with open(pkg_manifest, "r") as f:
        manifest = json.load(f)
    
    if manifest.get("name") != pkg_name:
        print("manifest.json name mismatch with package folder")
        return
    
    print("Installing package...")
    
    target_pkg_ins = os.path.join(INSTALLED_PACKAGE_DIR, pkg_name)
    os.makedirs(target_pkg_ins, exist_ok=True)
    
    pkg_apps = os.path.join(full_path, "app")
    
    if not os.path.exists(pkg_apps):
        print("No app folder in package")
        return
    
    for item in os.listdir(pkg_apps):
        src = os.path.join(pkg_apps, item)
        dst = os.path.join(target_pkg_ins, item)
        
        if os.path.isdir(src):
            shutil.copytree(src, dst, dirs_exist_ok=True)
        else:
            shutil.copy(src, dst)
    
    installed[pkg_name] = manifest
    
    with open(ins_json_path, "w") as f:
        json.dump(installed, f, indent=4)
        
    
    print("Install success")


def delete_pkg(pkg_name):
    full_path = os.path.join(INSTALLED_PACKAGE_DIR, pkg_name)
    
    if not os.path.exists(full_path):
        print("Package not found/already deleted")
        return
        
    with open(ins_json_path, "r") as f:
        installed = json.load(f)
        
    if not pkg_name in installed:
        print("Data in installed.json not found")
        return
        
    del installed[pkg_name]
    shutil.rmtree(full_path)
    with open(ins_json_path, "w") as f:
        json.dump(installed, f, indent=4)
    
    print("Package removed")