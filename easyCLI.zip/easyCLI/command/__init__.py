from .general import *
from .package_loader import *

BASE_COMMAND = {
	"echo": echo,
	"ls": ls,
	"touch": touch,
	"rm": rm,
	"mkdir": mkdir,
	"cd": cd,
	"cp": cp,
	"mv": mv,
	"pkg": pkg,
}

command_map = dict(BASE_COMMAND)

def reload_cm():
    command_map.clear()
    command_map.update(BASE_COMMAND)
    load_package_commands(command_map)