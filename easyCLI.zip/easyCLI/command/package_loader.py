import os
import importlib.util

INSTALLED_PACKAGE_DIR = os.path.abspath(".//installed_package")

def load_package_commands(command_map):
    if not os.path.exists(INSTALLED_PACKAGE_DIR):
        return

    for pkg in os.listdir(INSTALLED_PACKAGE_DIR):
        pkg_path = os.path.join(INSTALLED_PACKAGE_DIR, pkg)
        cmd_file = os.path.join(pkg_path, "commands.py")

        if not os.path.isfile(cmd_file):
            continue

        spec = importlib.util.spec_from_file_location(
            f"{pkg}_commands", cmd_file
        )
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)

        if hasattr(module, "register"):
            module.register(command_map)