import os

SANDBOX_DIR = os.path.abspath(".//sandbox")

def python(*args):
    if not args:
        print("Usage: python <file.py>")
        return

    filename = args[0]

    if not filename.endswith(".py"):
        print("Error: only .py files allowed")
        return

    file_path = os.path.join(SANDBOX_DIR, filename)

    if not os.path.isfile(file_path):
        print(f"File not found: {filename}")
        return

    try:
        runtime_globals = {
            "__name__": "__main__",
            "__file__": file_path,
        }

        with open(file_path, "r") as f:
            code = f.read()

        exec(code, runtime_globals)

    except Exception as e:
        print(f"[python error] {e}")

def register(command_map):
    command_map["python"] = python